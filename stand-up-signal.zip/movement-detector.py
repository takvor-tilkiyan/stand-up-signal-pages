from gpiozero import MotionSensor
from gpiozero import LED
from time import sleep
from datetime import datetime
from datetime import timedelta

pir = MotionSensor(4)
led = LED(17)
DETECTION_CYCLE_SECONDS = 120
DETECTION_POLL_SECONDS = 2
HEARTBEAT_MINUTE_OF_HOUR = 0

try:
    monitor_start = datetime.now()
    heartbeat_hour = datetime.now().hour - 1
    is_led_flashing = False
    while True:

        movement_detected = False
        check_start = datetime.now()
        while datetime.now() - check_start < timedelta(seconds=DETECTION_CYCLE_SECONDS):
            if not is_led_flashing and datetime.now().minute == HEARTBEAT_MINUTE_OF_HOUR and datetime.now().hour != heartbeat_hour:
                print("Flashing LED once as a heartbeat check for this script at " + datetime.now().isoformat())
                led.blink(n=1)
                heartbeat_hour = datetime.now().hour
            sleep(DETECTION_POLL_SECONDS)
            if pir.motion_detected:
                print("Movement at " + datetime.now().isoformat())
                movement_detected = True
                break

        if not movement_detected:
            print("No movement - turning LED off at " + datetime.now().isoformat())
            led.off()
            is_led_flashing = False
            monitor_start = datetime.now()
            continue

        if datetime.now() - monitor_start > timedelta(hours=1):
            print("Long period movements - flashing LED at " + datetime.now().isoformat())
            led.blink()
            is_led_flashing = True

except KeyboardInterrupt:
    print("Cleaning up at " + datetime.now().isoformat())

    print("Turning LED off at " + datetime.now().isoformat())
    led.off()

